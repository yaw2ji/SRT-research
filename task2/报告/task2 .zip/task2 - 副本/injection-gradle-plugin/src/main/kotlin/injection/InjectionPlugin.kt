package injection

import injection.bytecode.BytecodeRegistrar
import injection.config.PromptLibraryLoader
import injection.rollback.RollbackManifestTask
import injection.rules.ProguardRulesGenerator
import injection.task.InjectManifestTask
import injection.task.VerifyManifestTask
import org.gradle.api.Action
import org.gradle.api.Plugin
import org.gradle.api.Project
import java.io.File

abstract class InjectionPlugin : Plugin<Project> {
    override fun apply(project: Project) {
        project.plugins.withId("com.android.application") {
            BytecodeRegistrar.register(project)
            project.afterEvaluate { registerInjectionTasks(project) }
        }
        project.plugins.withId("com.android.library") {
            BytecodeRegistrar.register(project)
            project.afterEvaluate { registerInjectionTasks(project) }
        }
    }

    private fun registerInjectionTasks(project: Project) {
        val configFile = project.rootProject.layout.projectDirectory.file("injection-config.json")
        val promptsFilePath = project.rootProject.layout.projectDirectory.file("prompts/cbrn-prompts.json")

        val configFileObj = configFile.asFile
        if (configFileObj.exists()) {
            try {
                val config = PromptLibraryLoader.loadConfig(configFileObj)
                val targets = config.bytecode
                if (!targets.isNullOrEmpty()) {
                    val rulesFile = File(project.buildDir, "generated/injection/proguard-rules-injection.pro")
                    ProguardRulesGenerator.generate(targets, rulesFile)
                    project.logger.lifecycle("[InjectionPlugin] R8 keep rules: ${rulesFile.absolutePath}")
                }
            } catch (e: Exception) {
                project.logger.warn("[InjectionPlugin] R8 rules: ${e.message}")
            }
        }

        val manifestTaskPattern = Regex("^process(.+?)Manifest\$")
        val variantNames = project.tasks.names
            .mapNotNull { name -> manifestTaskPattern.find(name)?.groupValues?.get(1) }
            .filter { it.isNotEmpty() }
            .distinct()

        project.logger.lifecycle("[InjectionPlugin] Variants: ${variantNames.joinToString()}")

        variantNames.forEach { variantName ->
            val capitalized = variantName.replaceFirstChar { it.uppercase() }
            val manifestPath = project.layout.buildDirectory.file(
                "intermediates/merged_manifests/$variantName/process${capitalized}Manifest/AndroidManifest.xml"
            )

            // Inject task
            val injectTask = project.tasks.register(
                "inject${capitalized}Manifest", InjectManifestTask::class.java,
                object : Action<InjectManifestTask> {
                    override fun execute(t: InjectManifestTask) {
                        t.mergedManifest.set(manifestPath)
                        t.injectionConfig.set(configFile)
                        t.promptsFile.set(promptsFilePath)
                    }
                }
            )
            injectTask.configure(object : Action<InjectManifestTask> {
                override fun execute(t: InjectManifestTask) { t.dependsOn("process${capitalized}Manifest") }
            })

            // Verify task
            val verifyTask = project.tasks.register(
                "verify${capitalized}Manifest", VerifyManifestTask::class.java,
                object : Action<VerifyManifestTask> {
                    override fun execute(t: VerifyManifestTask) {
                        t.mergedManifest.set(manifestPath)
                        t.injectionConfig.set(configFile)
                        t.promptsFile.set(promptsFilePath)
                    }
                }
            )
            verifyTask.configure(object : Action<VerifyManifestTask> {
                override fun execute(t: VerifyManifestTask) { t.dependsOn("process${capitalized}Manifest") }
            })

            // Rollback task
            val rollbackTask = project.tasks.register(
                "rollback${capitalized}Manifest", RollbackManifestTask::class.java,
                object : Action<RollbackManifestTask> {
                    override fun execute(t: RollbackManifestTask) { t.mergedManifest.set(manifestPath) }
                }
            )
            rollbackTask.configure(object : Action<RollbackManifestTask> {
                override fun execute(t: RollbackManifestTask) { t.dependsOn("process${capitalized}Manifest") }
            })

            project.tasks.findByName("process${capitalized}Resources")?.dependsOn(injectTask)
        }

        if (project.tasks.findByName("injectionReport") == null) {
            project.tasks.register("injectionReport", injection.report.InjectionReportTask::class.java)
        }
    }
}
