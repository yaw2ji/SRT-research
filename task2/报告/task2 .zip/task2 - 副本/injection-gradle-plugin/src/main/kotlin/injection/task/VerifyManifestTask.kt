package injection.task

import injection.config.PromptLibraryLoader
import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory

abstract class VerifyManifestTask : DefaultTask() {

    @get:Internal
    abstract val mergedManifest: RegularFileProperty

    @get:Internal
    abstract val injectionConfig: RegularFileProperty

    @get:Internal
    abstract val promptsFile: RegularFileProperty

    @TaskAction
    fun execute() {
        val divider = "=".repeat(60)

        logger.lifecycle(divider)
        logger.lifecycle("[Verify] Pre-injection verification")
        logger.lifecycle(divider)

        val manifestFile = mergedManifest.get().asFile

        // 1. Check manifest exists
        if (!manifestFile.exists()) {
            logger.error("[Verify] FAIL: Merged manifest not found at ${manifestFile.absolutePath}")
            return
        }
        logger.lifecycle("[Verify] OK: Manifest found at ${manifestFile.absolutePath}")

        // 2. Parse and check <application>
        val docFactory = DocumentBuilderFactory.newInstance()
        val document = docFactory.newDocumentBuilder().parse(manifestFile)
        val applications = document.getElementsByTagName("application")

        if (applications.length == 0) {
            logger.error("[Verify] FAIL: No <application> element found")
            return
        }
        logger.lifecycle("[Verify] OK: <application> element found")

        // 3. Check for existing injection
        val application = applications.item(0) as Element
        var existingName: String? = null
        val metaDataNodes = application.getElementsByTagName("meta-data")
        for (i in 0 until metaDataNodes.length) {
            val meta = metaDataNodes.item(i) as Element
            val name = meta.getAttribute("android:name")
            if (name == "guardrail.notice") {
                existingName = name
                break
            }
        }

        if (existingName != null) {
            logger.warn("[Verify] WARN: meta-data '$existingName' already exists - would be skipped")
        } else {
            logger.lifecycle("[Verify] OK: No existing injection detected")
        }

        // 4. Load and validate config
        val configFile = injectionConfig.get().asFile
        if (!configFile.exists()) {
            logger.warn("[Verify] WARN: injection-config.json not found")
        } else {
            val config = PromptLibraryLoader.loadConfig(configFile)
            val manifestCfg = config.manifest
            if (manifestCfg == null || !manifestCfg.effectiveEnabled()) {
                logger.warn("[Verify] WARN: Manifest injection is disabled in config")
            } else {
                logger.lifecycle("[Verify] OK: Manifest injection enabled, mode=${manifestCfg.effectiveMode()}")
            }
        }

        // 5. Check prompt library is loadable
        try {
            val promptFile = promptsFile.get().asFile
            val library = PromptLibraryLoader.load(promptFile)
            val categoryCount = library.effectiveCategories().size
            val promptCount = library.effectiveCategories().values.sumOf { it.effectivePrompts().size }
            logger.lifecycle("[Verify] OK: Prompt library v${library.effectiveVersion()} loaded ($categoryCount categories, $promptCount prompts)")
        } catch (e: Exception) {
            logger.error("[Verify] FAIL: Cannot load prompt library: ${e.message}")
        }

        logger.lifecycle(divider)
        logger.lifecycle("[Verify] Verification complete")
    }
}
