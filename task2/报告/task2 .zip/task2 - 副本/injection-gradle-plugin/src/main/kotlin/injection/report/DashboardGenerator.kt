package injection.report

import injection.config.InjectionConfig
import injection.config.PromptLibrary
import injection.manifest.InjectionHistory
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object DashboardGenerator {

    fun generate(
        outputFile: File,
        config: InjectionConfig?,
        library: PromptLibrary?,
        rulesFile: File?,
        historyRoot: File?,
        appName: String,
        variantCount: Int
    ) {
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val now = df.format(Date())

        val manifestEnabled = config?.manifest?.effectiveEnabled() ?: false
        val manifestMode = config?.manifest?.effectiveMode() ?: "N/A"
        val bytecodeTargets = config?.bytecode ?: emptyList()

        val catCount = library?.effectiveCategories()?.size ?: 0
        val promptCount = library?.effectiveCategories()?.values?.sumOf { it.effectivePrompts().size } ?: 0

        // Collect history
        val historyEntries = mutableListOf<HistoryEntry>()
        if (historyRoot != null && historyRoot.exists()) {
            historyRoot.listFiles()?.forEach { variantDir ->
                val hf = File(variantDir, "history.json")
                if (hf.exists()) {
                    try {
                        val gson = com.google.gson.Gson()
                        val hist = gson.fromJson(hf.readText(), InjectionHistory::class.java)
                        hist.entries.forEach { entry ->
                            historyEntries.add(
                                HistoryEntry(
                                    timestamp = entry.timestamp,
                                    variant = entry.variant,
                                    status = if (entry.success) "SUCCESS" else "FAILED",
                                    hashBefore = entry.hashBefore.take(12),
                                    hashAfter = entry.hashAfter.take(12)
                                )
                            )
                        }
                    } catch (_: Exception) {}
                }
            }
        }

        val manifestSuccess = historyEntries.count { it.status == "SUCCESS" }
        val manifestTotal = historyEntries.size
        val bytecodeTotal = bytecodeTargets.size * variantCount
        val bytecodeSuccess = bytecodeTotal // Assume success if build passed

        val html = buildHtml(
            appName = appName, now = now,
            manifestEnabled = manifestEnabled, manifestMode = manifestMode,
            manifestSuccess = manifestSuccess, manifestTotal = manifestTotal,
            bytecodeSuccess = bytecodeSuccess, bytecodeTotal = bytecodeTotal,
            catCount = catCount, promptCount = promptCount,
            rulesPath = rulesFile?.absolutePath ?: "not generated",
            rulesSize = rulesFile?.length() ?: 0,
            historyEntries = historyEntries
        )

        outputFile.parentFile?.mkdirs()
        outputFile.writeText(html, Charsets.UTF_8)
    }

    private fun buildHtml(
        appName: String, now: String,
        manifestEnabled: Boolean, manifestMode: String,
        manifestSuccess: Int, manifestTotal: Int,
        bytecodeSuccess: Int, bytecodeTotal: Int,
        catCount: Int, promptCount: Int,
        rulesPath: String, rulesSize: Long,
        historyEntries: List<HistoryEntry>
    ): String = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>Injection Dashboard — $appName</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:24px}
h1{font-size:24px;margin-bottom:4px}
.subtitle{color:#94a3b8;font-size:13px;margin-bottom:24px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-bottom:24px}
.card{background:#1e293b;border-radius:12px;padding:20px;border:1px solid #334155}
.card h3{font-size:11px;text-transform:uppercase;color:#64748b;margin-bottom:8px;letter-spacing:0.5px}
.card .value{font-size:28px;font-weight:700}
.success{color:#22c55e}.warn{color:#eab308}.fail{color:#ef4444}.info{color:#3b82f6}
table{width:100%;border-collapse:collapse;background:#1e293b;border-radius:12px;overflow:hidden;border:1px solid #334155}
th{background:#334155;padding:10px 14px;text-align:left;font-size:12px;text-transform:uppercase;color:#94a3b8}
td{padding:10px 14px;font-size:13px;border-top:1px solid #1e293b}
tr:hover{background:#0f172a}
.badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600}
.badge-ok{background:#22c55e20;color:#22c55e}
.badge-warn{background:#eab30820;color:#eab308}
.footer{margin-top:24px;color:#475569;font-size:11px;text-align:center}
</style>
</head>
<body>
<h1>Injection Dashboard</h1>
<p class="subtitle">$appName &middot; Generated $now</p>

<div class="cards">
  <div class="card">
    <h3>Manifest Injection</h3>
    <div class="value ${if(manifestEnabled) "success" else "warn"}">${if(manifestEnabled) "ON" else "OFF"}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px">Mode: $manifestMode</p>
  </div>
  <div class="card">
    <h3>Manifest Results</h3>
    <div class="value ${if(manifestSuccess > 0) "success" else "info"}">$manifestSuccess/$manifestTotal</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px">Variants injected</p>
  </div>
  <div class="card">
    <h3>Bytecode Injection</h3>
    <div class="value ${if(bytecodeTotal > 0) "success" else "info"}">$bytecodeSuccess/$bytecodeTotal</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px">Targets x variants</p>
  </div>
  <div class="card">
    <h3>Prompt Library</h3>
    <div class="value info">$promptCount</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px">Prompts in $catCount categories</p>
  </div>
  <div class="card">
    <h3>R8 Keep Rules</h3>
    <div class="value ${if(rulesSize > 0) "success" else "warn"}">${if(rulesSize > 0) "OK" else "N/A"}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px;word-break:break-all">${rulesPath.takeLast(50)}</p>
  </div>
  <div class="card">
    <h3>Agent Trigger</h3>
    <div class="value warn">Pending</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:4px">Requires AI agent testing</p>
  </div>
</div>

<h2 style="font-size:16px;margin:20px 0 12px">Injection History</h2>
${if (historyEntries.isEmpty()) """<p style="color:#64748b;font-size:13px">No records yet. Run inject tasks to populate.</p>"""
else """
<table>
<thead><tr><th>Time</th><th>Variant</th><th>Status</th><th>Hash Before</th><th>Hash After</th></tr></thead>
<tbody>
${historyEntries.joinToString("\n") { e ->
"<tr><td>${SimpleDateFormat("HH:mm:ss").format(Date(e.timestamp))}</td><td>${e.variant}</td><td><span class=\"badge ${if(e.status=="SUCCESS") "badge-ok" else "badge-warn"}\">${e.status}</span></td><td style=\"font-family:monospace;font-size:11px\">${e.hashBefore}...</td><td style=\"font-family:monospace;font-size:11px\">${e.hashAfter}...</td></tr>"
}}
</tbody>
</table>
"""
}

<p class="footer">Injection Plugin v1.0 &middot; org.example.injection</p>
</body>
</html>
    """

    data class HistoryEntry(
        val timestamp: Long,
        val variant: String,
        val status: String,
        val hashBefore: String,
        val hashAfter: String
    )
}
