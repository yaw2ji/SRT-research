package injection.bytecode

import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.FieldVisitor
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes
import org.gradle.api.logging.Logger

class InjectionClassVisitor(
    nextClassVisitor: ClassVisitor,
    private val className: String,
    private val targetMethod: String,
    private val targetDescriptor: String,
    private val anchor: String,
    private val promptText: String,
    private val fieldName: String,
    private val localVarName: String,
    private val targetCallOwner: String,
    private val targetCallName: String,
    private val targetCallDescriptor: String,
    private val logger: Logger
) : ClassVisitor(Opcodes.ASM9, nextClassVisitor) {

    private var fieldAlreadyExists = false
    private var methodMatchCount = 0
    private val internalClassName = className.replace('.', '/')

    override fun visitField(
        access: Int,
        name: String?,
        descriptor: String?,
        signature: String?,
        value: Any?
    ): FieldVisitor? {
        if (name == fieldName &&
            (access and Opcodes.ACC_STATIC) != 0 &&
            (access and Opcodes.ACC_FINAL) != 0 &&
            descriptor == "Ljava/lang/String;"
        ) {
            fieldAlreadyExists = true
            logger.lifecycle(
                "[BytecodeInjection] Field '$fieldName' already exists in $className. Skipping field creation."
            )
        }
        return super.visitField(access, name, descriptor, signature, value)
    }

    override fun visitEnd() {
        if (!fieldAlreadyExists) {
            val fv = super.visitField(
                Opcodes.ACC_PUBLIC or Opcodes.ACC_STATIC or Opcodes.ACC_FINAL,
                fieldName,
                "Ljava/lang/String;",
                null,
                promptText
            )
            fv?.visitEnd()
            logger.lifecycle(
                "[BytecodeInjection] Added static final field '$fieldName' to $className"
            )
        }

        // Validate method matching
        if (targetDescriptor.isEmpty() && methodMatchCount > 1) {
            throw IllegalStateException(
                "[BytecodeInjection] Method '$targetMethod' matches $methodMatchCount methods in $className. " +
                "Please specify a JVM descriptor in the injection config to disambiguate."
            )
        }
        if (methodMatchCount == 0) {
            throw IllegalStateException(
                "[BytecodeInjection] Method '$targetMethod' not found in $className. " +
                "Please check the class name, method name, and descriptor in injection-config.json."
            )
        }

        super.visitEnd()
    }

    override fun visitMethod(
        access: Int,
        name: String?,
        descriptor: String?,
        signature: String?,
        exceptions: Array<out String>?
    ): MethodVisitor? {
        val mv = super.visitMethod(access, name, descriptor, signature, exceptions)

        if (name == "<init>" || name == "<clinit>") return mv
        if (name != targetMethod) return mv

        // If a specific descriptor is required, check for exact match
        if (targetDescriptor.isNotEmpty() && descriptor != targetDescriptor) return mv

        methodMatchCount++

        logger.lifecycle(
            "[BytecodeInjection] Instrumenting method '$name$descriptor' in $className (anchor=$anchor)"
        )

        return InjectionMethodVisitor(
            api = Opcodes.ASM9,
            methodVisitor = mv,
            access = access,
            name = name ?: "",
            descriptor = descriptor ?: "",
            internalClassName = internalClassName,
            anchor = anchor,
            promptText = promptText,
            fieldName = fieldName,
            localVarName = localVarName,
            targetCallOwner = targetCallOwner,
            targetCallName = targetCallName,
            targetCallDescriptor = targetCallDescriptor,
            logger = logger
        )
    }
}
