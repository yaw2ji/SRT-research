package injection.rollback

import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.StringWriter
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

abstract class RollbackManifestTask : DefaultTask() {

    @get:Internal
    abstract val mergedManifest: RegularFileProperty

    @TaskAction
    fun execute() {
        val manifestFile = mergedManifest.get().asFile

        if (!manifestFile.exists()) {
            logger.lifecycle("[Rollback] Manifest not found at ${manifestFile.absolutePath}")
            return
        }

        val docFactory = DocumentBuilderFactory.newInstance()
        val document = docFactory.newDocumentBuilder().parse(manifestFile)
        val applications = document.getElementsByTagName("application")
        if (applications.length == 0) {
            logger.lifecycle("[Rollback] No <application> element found. Nothing to roll back.")
            return
        }
        val application = applications.item(0) as Element

        // Find all injected meta-data nodes
        val metaDataNodes = application.getElementsByTagName("meta-data")
        val toRemove = mutableListOf<Element>()
        for (i in 0 until metaDataNodes.length) {
            val meta = metaDataNodes.item(i) as Element
            val name = meta.getAttribute("android:name")
            if (name == "guardrail.notice") {
                toRemove.add(meta)
            }
        }

        if (toRemove.isEmpty()) {
            logger.lifecycle("[Rollback] No injected meta-data found. Nothing to roll back.")
            return
        }

        toRemove.forEach { meta ->
            // Remove adjacent whitespace text nodes for clean output
            val prevSibling = meta.previousSibling
            application.removeChild(meta)
            if (prevSibling != null && prevSibling.nodeType == Node.TEXT_NODE &&
                prevSibling.textContent.trim().isEmpty()
            ) {
                application.removeChild(prevSibling)
            }
        }

        // Serialize back
        val transformer = TransformerFactory.newInstance().newTransformer()
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        transformer.setOutputProperty(OutputKeys.INDENT, "yes")
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4")
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")

        val writer = StringWriter()
        transformer.transform(DOMSource(document), StreamResult(writer))
        manifestFile.writeText(writer.toString(), Charsets.UTF_8)

        logger.lifecycle("[Rollback] Removed ${toRemove.size} injected meta-data entries from ${manifestFile.absolutePath}")
    }
}
