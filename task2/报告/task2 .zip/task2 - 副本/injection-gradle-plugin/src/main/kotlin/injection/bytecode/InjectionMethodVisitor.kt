package injection.bytecode

import org.objectweb.asm.Opcodes
import org.objectweb.asm.Type
import org.objectweb.asm.commons.AdviceAdapter
import org.gradle.api.logging.Logger

class InjectionMethodVisitor(
    api: Int,
    methodVisitor: org.objectweb.asm.MethodVisitor?,
    access: Int,
    private val name: String,
    descriptor: String,
    private val internalClassName: String,
    private val anchor: String,
    private val promptText: String,
    private val fieldName: String,
    private val localVarName: String,
    private val targetCallOwner: String,
    private val targetCallName: String,
    private val targetCallDescriptor: String,
    private val logger: Logger
) : AdviceAdapter(api, methodVisitor, access, name, descriptor) {

    private var injectionDone = false

    override fun visitCode() {
        super.visitCode()
        if (anchor == "method-entry" && !injectionDone) {
            injectFieldReference()
            injectionDone = true
        }
    }

    override fun visitMethodInsn(
        opcode: Int,
        owner: String?,
        name: String?,
        descriptor: String?,
        isInterface: Boolean
    ) {
        if (!injectionDone && anchor == "before:target-call") {
            val match =
                (targetCallOwner.isEmpty() || owner == targetCallOwner) &&
                (targetCallName.isEmpty() || name == targetCallName) &&
                (targetCallDescriptor.isEmpty() || descriptor == targetCallDescriptor)

            if (match) {
                logger.lifecycle(
                    "[BytecodeInjection] Injecting before target call: $owner.$name$descriptor"
                )
                injectFieldReference()
                injectionDone = true
            }
        }
        super.visitMethodInsn(opcode, owner, name, descriptor, isInterface)
    }

    private fun injectFieldReference() {
        logger.lifecycle(
            "[BytecodeInjection] Injecting field reference in $name of $internalClassName"
        )
        val stringType = Type.getType("Ljava/lang/String;")
        val localVarSlot = newLocal(stringType)

        // GETSTATIC: load static field
        visitFieldInsn(Opcodes.GETSTATIC, internalClassName, fieldName, "Ljava/lang/String;")
        // ASTORE: store to local variable
        visitVarInsn(Opcodes.ASTORE, localVarSlot)
    }
}
