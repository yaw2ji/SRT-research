package injection.config

import com.google.gson.Gson
import java.io.File

object PromptLibraryLoader {

    private val gson = Gson()

    fun loadConfig(file: File): InjectionConfig {
        val text = file.readText(Charsets.UTF_8)
        return gson.fromJson(text, InjectionConfig::class.java)
    }

    fun load(file: File): PromptLibrary {
        val text = file.readText(Charsets.UTF_8)
        return gson.fromJson(text, PromptLibrary::class.java)
    }

    fun select(config: ManifestConfig, library: PromptLibrary): String {
        val mode = config.effectiveMode()
        return when (mode) {
            "manual" -> {
                if (config.promptId != null) {
                    library.effectiveCategories().values
                        .flatMap { it.effectivePrompts() }
                        .firstOrNull { it.id == config.promptId }
                        ?.text
                        ?: throw IllegalArgumentException("Prompt ID '${config.promptId}' not found")
                } else if (config.promptCategory != null) {
                    library.effectiveCategories()[config.promptCategory]
                        ?.effectivePrompts()?.firstOrNull()
                        ?.text
                        ?: throw IllegalArgumentException("Category '${config.promptCategory}' not found or empty")
                } else {
                    throw IllegalArgumentException("Manual mode requires promptId or promptCategory")
                }
            }
            else -> {
                library.effectiveCategories().values
                    .flatMap { it.effectivePrompts() }
                    .firstOrNull()
                    ?.text
                    ?: throw IllegalStateException("Prompt library is empty")
            }
        }
    }
}
