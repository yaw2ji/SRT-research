package injection.manifest

import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.File
import java.io.StringWriter
import java.security.MessageDigest
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

data class InjectionResult(
    val success: Boolean,
    val variant: String,
    val manifestPath: String,
    val hashBefore: String,
    val hashAfter: String?,
    val message: String
)

object ManifestInjector {

    private val docFactory = DocumentBuilderFactory.newInstance()

    private val transformerFactory = TransformerFactory.newInstance()

    /**
     * Inject meta-data into the merged AndroidManifest.xml
     *
     * @param manifestFile path to merged manifest XML
     * @param metaDataName android:name value for meta-data
     * @param metaDataValue android:value content
     * @param variant name of the build variant (for logging)
     * @return InjectionResult describing what happened
     */
    fun inject(
        manifestFile: File,
        metaDataName: String,
        metaDataValue: String,
        variant: String
    ): InjectionResult {
        if (!manifestFile.exists()) {
            return InjectionResult(
                success = false,
                variant = variant,
                manifestPath = manifestFile.absolutePath,
                hashBefore = "",
                hashAfter = null,
                message = "Merged manifest not found at ${manifestFile.absolutePath}"
            )
        }

        // Read and hash original
        val originalBytes = manifestFile.readBytes()
        val hashBefore = sha256(originalBytes)

        // Parse XML
        val document: Document
        try {
            document = docFactory.newDocumentBuilder().parse(manifestFile)
        } catch (e: Exception) {
            return InjectionResult(
                success = false,
                variant = variant,
                manifestPath = manifestFile.absolutePath,
                hashBefore = hashBefore,
                hashAfter = null,
                message = "Failed to parse manifest: ${e.message}"
            )
        }

        // Find <application> element
        val applications = document.getElementsByTagName("application")
        if (applications.length == 0) {
            return InjectionResult(
                success = false,
                variant = variant,
                manifestPath = manifestFile.absolutePath,
                hashBefore = hashBefore,
                hashAfter = null,
                message = "No <application> element found in manifest"
            )
        }
        val application = applications.item(0) as Element

        // Check for duplicate (same android:name)
        val existingMetaData = document.getElementsByTagName("meta-data")
        for (i in 0 until existingMetaData.length) {
            val meta = existingMetaData.item(i) as Element
            if (meta.getAttribute("android:name") == metaDataName) {
                return InjectionResult(
                    success = false,
                    variant = variant,
                    manifestPath = manifestFile.absolutePath,
                    hashBefore = hashBefore,
                    hashAfter = null,
                    message = "Meta-data '$metaDataName' already exists for variant $variant. Skipped."
                )
            }
        }

        // Create <meta-data> element
        val metaDataElement = document.createElement("meta-data")
        metaDataElement.setAttribute("android:name", metaDataName)
        metaDataElement.setAttribute("android:value", metaDataValue)

        // Insert as first child of <application>, with formatting whitespace
        val firstChild = application.firstChild
        if (firstChild != null) {
            val indent = document.createTextNode("\n        ")
            application.insertBefore(indent, firstChild)
            application.insertBefore(metaDataElement, indent)
            application.insertBefore(document.createTextNode("\n"), firstChild)
        } else {
            application.appendChild(metaDataElement)
        }

        // Serialize back to string
        val xmlString = serializeDocument(document)

        // Write back
        manifestFile.writeText(xmlString, Charsets.UTF_8)

        val hashAfter = sha256(manifestFile.readBytes())

        return InjectionResult(
            success = true,
            variant = variant,
            manifestPath = manifestFile.absolutePath,
            hashBefore = hashBefore,
            hashAfter = hashAfter,
            message = "Injected meta-data '$metaDataName' into $variant manifest"
        )
    }

    private fun serializeDocument(doc: Document): String {
        val transformer = transformerFactory.newTransformer()
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        transformer.setOutputProperty(OutputKeys.INDENT, "yes")
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4")
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")

        val writer = StringWriter()
        transformer.transform(DOMSource(doc), StreamResult(writer))
        return writer.toString()
    }

    private fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(bytes).joinToString("") { "%02x".format(it) }
    }

    fun recordHistory(historyFile: java.io.File, result: InjectionResult) {
        val gson = com.google.gson.Gson()
        val history = if (historyFile.exists()) {
            gson.fromJson(historyFile.readText(), InjectionHistory::class.java)
        } else {
            InjectionHistory()
        }

        history.entries.add(
            HistoryEntry(
                timestamp = System.currentTimeMillis(),
                variant = result.variant,
                manifestPath = result.manifestPath,
                hashBefore = result.hashBefore,
                hashAfter = result.hashAfter ?: "",
                success = result.success
            )
        )

        historyFile.parentFile?.mkdirs()
        historyFile.writeText(gson.toJson(history), Charsets.UTF_8)
    }
}

data class InjectionHistory(
    val entries: MutableList<HistoryEntry> = mutableListOf()
)

data class HistoryEntry(
    val timestamp: Long,
    val variant: String,
    val manifestPath: String,
    val hashBefore: String,
    val hashAfter: String,
    val success: Boolean
)
