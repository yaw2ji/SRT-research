package injection.bytecode

import com.android.build.api.instrumentation.AsmClassVisitorFactory
import com.android.build.api.instrumentation.ClassContext
import com.android.build.api.instrumentation.ClassData
import org.gradle.api.logging.Logging
import org.objectweb.asm.ClassVisitor

abstract class BytecodeInjectionFactory : AsmClassVisitorFactory<InjectionParameters> {

    override fun isInstrumentable(classData: ClassData): Boolean {
        val targetClass = parameters.get().targetClass.get()
        if (classData.className != targetClass) return false
        if (classData.className.contains("\$")) return false
        return true
    }

    override fun createClassVisitor(
        classContext: ClassContext,
        nextClassVisitor: ClassVisitor
    ): ClassVisitor {
        val params = parameters.get()
        return InjectionClassVisitor(
            nextClassVisitor = nextClassVisitor,
            className = classContext.currentClassData.className,
            targetMethod = params.targetMethod.get(),
            targetDescriptor = params.targetDescriptor.get(),
            anchor = params.anchor.get(),
            promptText = params.promptText.get(),
            fieldName = params.fieldName.get(),
            localVarName = params.localVarName.get(),
            targetCallOwner = params.targetCallOwner.orNull ?: "",
            targetCallName = params.targetCallName.orNull ?: "",
            targetCallDescriptor = params.targetCallDescriptor.orNull ?: "",
            logger = Logging.getLogger(BytecodeInjectionFactory::class.java)
        )
    }
}
