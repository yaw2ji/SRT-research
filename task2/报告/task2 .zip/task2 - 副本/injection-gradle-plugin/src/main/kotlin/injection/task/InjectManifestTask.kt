package injection.task

import injection.config.PromptLibraryLoader
import injection.manifest.ManifestInjector
import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import java.io.File

abstract class InjectManifestTask : DefaultTask() {

    @get:Internal
    abstract val mergedManifest: RegularFileProperty

    @get:Internal
    abstract val injectionConfig: RegularFileProperty

    @get:Internal
    abstract val promptsFile: RegularFileProperty

    @TaskAction
    fun execute() {
        val configFile = injectionConfig.get().asFile
        if (!configFile.exists()) {
            logger.lifecycle("[Injection] injection-config.json not found. Skipping injection.")
            return
        }

        val promptFile = promptsFile.get().asFile
        if (!promptFile.exists()) {
            logger.error("[Injection] prompts/cbrn-prompts.json not found. Cannot inject.")
            return
        }

        val config = PromptLibraryLoader.loadConfig(configFile)
        val manifestCfg = config.manifest
        if (manifestCfg == null || !manifestCfg.effectiveEnabled()) {
            logger.lifecycle("[Injection] Manifest injection disabled. Skipping.")
            return
        }

        val library = PromptLibraryLoader.load(promptFile)
        val promptText = PromptLibraryLoader.select(manifestCfg, library)

        logger.lifecycle("[Injection] Prompt text: ${promptText.take(80)}...")
        logger.lifecycle("[Injection] Prompt text length: ${promptText.length} chars")

        val manifestFile = mergedManifest.get().asFile

        val result = ManifestInjector.inject(
            manifestFile = manifestFile,
            metaDataName = manifestCfg.effectiveMetaDataName(),
            metaDataValue = promptText,
            variant = extractVariantName(manifestFile)
        )

        if (result.success) {
            logger.lifecycle("[Injection] SUCCESS: ${result.message}")
            logger.lifecycle("[Injection] Hash before: ${result.hashBefore}")
            logger.lifecycle("[Injection] Hash after:  ${result.hashAfter}")

            // Record history: walk up to find the build directory
            val buildDir = findBuildDir(manifestFile)
            val historyFile = File(buildDir, "injection-history/${extractVariantName(manifestFile)}/history.json")
            ManifestInjector.recordHistory(historyFile, result)
        } else {
            logger.lifecycle("[Injection] SKIP/FAIL: ${result.message}")
        }
    }

    private fun extractVariantName(manifestFile: File): String {
        val parent = manifestFile.parentFile?.name ?: "unknown"
        return parent
    }

    private fun findBuildDir(file: File): File {
        var dir: File? = file.parentFile
        while (dir != null && dir.name != "build") {
            dir = dir.parentFile
        }
        return dir ?: file.parentFile?.parentFile?.parentFile ?: file
    }
}
