package injection.config

/**
 * Simple data classes for injection configuration.
 * Fields use nullable types internally for Gson deserialization;
 * defaults are applied through PromptLibraryLoader.loadConfig().
 */
data class InjectionConfig(
    val manifest: ManifestConfig? = null,
    val bytecode: List<BytecodeInjectionConfig>? = null
)

data class BytecodeInjectionConfig(
    val `class`: String? = null,
    val method: String? = null,
    val descriptor: String? = null,     // JVM descriptor, empty = match by name only
    val anchor: String? = null,         // "method-entry" or "before:target-call"
    val promptId: String? = null,
    val fieldName: String? = null,      // default "BACKUP_REVIEW_CONTEXT"
    val localVarName: String? = null,   // default "backupReviewContext"
    val targetCall: TargetCallConfig? = null
) {
    fun effectiveClass() = `class` ?: throw IllegalArgumentException("Bytecode injection requires 'class'")
    fun effectiveMethod() = method ?: throw IllegalArgumentException("Bytecode injection requires 'method'")
    fun effectiveAnchor() = anchor ?: "method-entry"
    fun effectiveFieldName() = fieldName ?: "BACKUP_REVIEW_CONTEXT"
    fun effectiveLocalVarName() = localVarName ?: "backupReviewContext"
}

data class TargetCallConfig(
    val owner: String? = null,       // internal JVM name: "kotlinx/serialization/json/Json"
    val name: String? = null,        // method name: "encodeToString"
    val descriptor: String? = null   // JVM descriptor: "(Ljava/lang/Object;)Ljava/lang/String;"
)

data class ManifestConfig(
    val enabled: Boolean? = null,
    val mode: String? = null,
    val promptId: String? = null,
    val promptCategory: String? = null,
    val metaDataName: String? = null
) {
    fun effectiveEnabled() = enabled ?: true
    fun effectiveMode() = mode ?: "auto"
    fun effectiveMetaDataName() = metaDataName ?: "guardrail.notice"
}

data class PromptLibrary(
    val version: String? = null,
    val categories: Map<String, PromptCategory>? = null
) {
    fun effectiveVersion() = version ?: "unknown"
    fun effectiveCategories() = categories ?: emptyMap()
}

data class PromptCategory(
    val label: String? = null,
    val prompts: List<PromptEntry>? = null
) {
    fun effectivePrompts() = prompts ?: emptyList()
}

data class PromptEntry(
    val id: String? = null,
    val text: String? = null
)
