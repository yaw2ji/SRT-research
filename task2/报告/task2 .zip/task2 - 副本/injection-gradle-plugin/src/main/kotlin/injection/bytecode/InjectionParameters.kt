package injection.bytecode

import com.android.build.api.instrumentation.InstrumentationParameters
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input

interface InjectionParameters : InstrumentationParameters {
    @get:Input
    val targetClass: Property<String>

    @get:Input
    val targetMethod: Property<String>

    @get:Input
    val targetDescriptor: Property<String>

    @get:Input
    val anchor: Property<String>

    @get:Input
    val promptText: Property<String>

    @get:Input
    val fieldName: Property<String>

    @get:Input
    val localVarName: Property<String>

    @get:Input
    val targetCallOwner: Property<String>

    @get:Input
    val targetCallName: Property<String>

    @get:Input
    val targetCallDescriptor: Property<String>
}
