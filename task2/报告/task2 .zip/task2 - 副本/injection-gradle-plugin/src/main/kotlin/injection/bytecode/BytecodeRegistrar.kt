package injection.bytecode

import com.android.build.api.instrumentation.InstrumentationScope
import com.android.build.api.variant.AndroidComponentsExtension
import injection.config.BytecodeInjectionConfig
import injection.config.PromptLibrary
import injection.config.PromptLibraryLoader
import org.gradle.api.Project
import org.gradle.api.logging.Logging

object BytecodeRegistrar {

    private val logger = Logging.getLogger(BytecodeRegistrar::class.java)

    fun register(project: Project) {
        val configFile = project.rootProject.layout.projectDirectory.file("injection-config.json").asFile
        if (!configFile.exists()) {
            logger.lifecycle("[BytecodeInjection] injection-config.json not found. Skipping.")
            return
        }

        val config = PromptLibraryLoader.loadConfig(configFile)
        val bytecodeTargets = config.bytecode
        if (bytecodeTargets.isNullOrEmpty()) return

        val promptLibraryFile = project.rootProject.layout.projectDirectory
            .file("prompts/cbrn-prompts.json").asFile
        val library: PromptLibrary? = if (promptLibraryFile.exists()) {
            PromptLibraryLoader.load(promptLibraryFile)
        } else null

        val androidComponents = project.extensions.getByType(AndroidComponentsExtension::class.java)

        androidComponents.onVariants { variant ->
            bytecodeTargets.forEach { target ->
                val promptText = resolvePromptText(target, library)
                val targetClass = target.effectiveClass()
                val targetMethod = target.effectiveMethod()
                val effectiveAnchor = target.effectiveAnchor()
                val callConfig = target.targetCall

                variant.instrumentation.transformClassesWith(
                    BytecodeInjectionFactory::class.java,
                    InstrumentationScope.ALL
                ) { params ->
                    params.targetClass.set(targetClass)
                    params.targetMethod.set(targetMethod)
                    params.targetDescriptor.set(target.descriptor ?: "")
                    params.anchor.set(effectiveAnchor)
                    params.promptText.set(promptText)
                    params.fieldName.set(target.effectiveFieldName())
                    params.localVarName.set(target.effectiveLocalVarName())
                    params.targetCallOwner.set(callConfig?.owner ?: "")
                    params.targetCallName.set(callConfig?.name ?: "")
                    params.targetCallDescriptor.set(callConfig?.descriptor ?: "")
                }

                logger.lifecycle("[BytecodeInjection] Registered: $targetClass.$targetMethod on variant '${variant.name}'")
            }
        }
    }

    private fun resolvePromptText(target: BytecodeInjectionConfig, library: PromptLibrary?): String {
        if (target.promptId != null && library != null) {
            return library.effectiveCategories().values
                .flatMap { it.effectivePrompts() }
                .firstOrNull { it.id == target.promptId }
                ?.text
                ?: throw IllegalArgumentException("Bytecode prompt ID '${target.promptId}' not found")
        }
        if (library != null) {
            return library.effectiveCategories().values
                .flatMap { it.effectivePrompts() }
                .firstOrNull()
                ?.text ?: ""
        }
        return ""
    }
}
