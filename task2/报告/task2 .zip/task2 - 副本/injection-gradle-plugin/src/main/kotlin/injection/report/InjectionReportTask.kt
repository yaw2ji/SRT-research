package injection.report

import injection.config.PromptLibraryLoader
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import java.io.File

abstract class InjectionReportTask : DefaultTask() {

    @TaskAction
    fun execute() {
        val divider = "=".repeat(70)
        logger.lifecycle(divider)
        logger.lifecycle("[Report] Injection Plugin Status Report")
        logger.lifecycle(divider)

        val projectDir = project.rootProject.projectDir
        val buildDir = project.buildDir

        val config = loadSafely(File(projectDir, "injection-config.json"))
        val library = loadLibrarySafely(File(projectDir, "prompts/cbrn-prompts.json"))

        // Console output
        logger.lifecycle("Manifest injection: ${config?.manifest?.let {
            if (it.effectiveEnabled()) "ENABLED (mode=${it.effectiveMode()})" else "DISABLED"
        } ?: "not configured"}")

        val targets = config?.bytecode
        if (targets.isNullOrEmpty()) {
            logger.lifecycle("Bytecode injection: no targets configured")
        } else {
            logger.lifecycle("Bytecode injection: ${targets.size} target(s)")
            targets.forEach { t ->
                logger.lifecycle("  - ${t.effectiveClass()}.${t.effectiveMethod()} [${t.effectiveAnchor()}]")
            }
        }

        val catCount = library?.effectiveCategories()?.size ?: 0
        val promptCount = library?.effectiveCategories()?.values?.sumOf { it.effectivePrompts().size } ?: 0
        logger.lifecycle("Prompt library: ${if (library != null) "v${library.effectiveVersion()} ($catCount categories, $promptCount prompts)" else "not found"}")

        val rulesFile = File(buildDir, "generated/injection/proguard-rules-injection.pro")
        if (rulesFile.exists())
            logger.lifecycle("R8 keep rules: ${rulesFile.absolutePath} (${rulesFile.length()} bytes)")
        else
            logger.lifecycle("R8 keep rules: not yet generated")

        val histRoot = File(buildDir, "injection-history")
        val histCount = if (histRoot.exists()) histRoot.listFiles()?.size ?: 0 else 0
        logger.lifecycle("Injection history: ${if (histCount > 0) "$histCount variant(s)" else "no records yet"}")

        // Variant count (estimate)
        val variantCount = project.tasks.names
            .count { it.matches(Regex("^process.*Manifest$")) }.coerceAtLeast(1)

        // Generate HTML dashboard
        val dashboardFile = File(buildDir, "reports/injection-dashboard.html")
        DashboardGenerator.generate(
            outputFile = dashboardFile,
            config = config,
            library = library,
            rulesFile = rulesFile,
            historyRoot = histRoot,
            appName = project.rootProject.name,
            variantCount = variantCount
        )

        logger.lifecycle("Dashboard: file://${dashboardFile.absolutePath.replace('\\', '/')}")
        logger.lifecycle(divider)
    }

    private fun loadSafely(file: File) = try {
        if (file.exists()) PromptLibraryLoader.loadConfig(file) else null
    } catch (e: Exception) { null }

    private fun loadLibrarySafely(file: File) = try {
        if (file.exists()) PromptLibraryLoader.load(file) else null
    } catch (e: Exception) { null }
}
