rootProject.name = "injection-gradle-plugin"
