plugins {
    kotlin("jvm") version "2.0.21"
    `java-gradle-plugin`
    `maven-publish`
}

group = "org.example.injection"
version = "1.0.0"

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation("com.android.tools.build:gradle:8.2.0")
    implementation("org.ow2.asm:asm-commons:9.7.1")
    implementation("com.google.code.gson:gson:2.11.0")
}

gradlePlugin {
    plugins {
        register("injectionPlugin") {
            id = "org.example.injection"
            implementationClass = "injection.InjectionPlugin"
        }
    }
}
